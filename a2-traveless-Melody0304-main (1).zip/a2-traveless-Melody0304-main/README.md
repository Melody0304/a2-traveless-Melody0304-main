# Traveless Assignment (CPRG 211)

This is the boiler-plate solution for assignment #2 for the CPRG211 (OOP 2) courses. Please see [Brightspace D2L](https://learn.sait.ca) for more information on this assignment.
